#
get 'inia_members', :to => 'inia_members#index'
# get 'inia_members/:id', :to => 'inia_members#index'
# put 'inia_members/:id', :to => 'inia_members#update', :as => 'add_member_rols'
# match 'inia_members/edit', :controller => 'inia_members', :action => 'edit', :via => [:get]
get 'inia_members/lacking_approvals', :to => 'inia_members#lacking_approvals'
get 'inia_members/group_users', :to => 'inia_members#group_users'
get 'inia_members/project_members', :to => 'inia_members#project_members'

match 'inia_members/set_approvers', :to => 'inia_members#set_approvers', :via => [:put, :post]
match 'inia_members/inia_roles', :to => 'inia_members#inia_roles', :via => [:get]
match 'inia_members/nanba_approval_roles', :to => 'inia_members#nanba_approval_roles', :via => [:get]
match 'inia_members/map_inia_roles', :to => 'inia_members#map_inia_roles', :via => [:put, :post]
match 'inia_members/delegation', :to => 'inia_members#delegation', :via => [:put, :post]
match 'inia_members/get_project_list', :to => 'inia_members#get_project_list', :via => [:put, :post]
match 'inia_members/set_delegation', :to => 'inia_members#set_delegation', :via => [:put, :post]



# resources :inia_members do
#   # collection do
#   #   get 'group_users'
#   #   get 'lacking_approvals'
#   # end
# end