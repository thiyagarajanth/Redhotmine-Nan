
$(document).ready(function(){

    var count = 4, sources = [], resource = '', inia_project_id='', role_id='', dep_id = '', cur_user_id='';
    var getSource = function() {
        return JSON.parse(JSON.stringify(sources));
    };

    var getQuery = function(options){
        options.callback({ results : sources });
    };
    tds = [];
    var table = $('.secondary-set-options tr:visible').not(':first').not(':last');
    table.each(function(){
        tds.push($(this).find('td').length)
    });
    var td_len =Math.max.apply(Math,tds);
    table.each(function(){
       var remain =  td_len - $(this).find('td').length;
        console.log([td_len , $(this).find('td').length])
        if (remain > 0){
            var i = remain;
            while (i--) {
               $(this).append("<td></td>")
            }
        }

    });



    $('.delegate').click(function(){
        var thi = $(this);
        var user_id = thi.data('user_id');
        var state = thi.closest('.secondary-set-options').attr('state')
        var aru_ids = [];
       $('.delegated_user_row').each(function(){
         aru_ids.push($(this).find('.username').map(function() { return $(this).data('aru_id') }).get())
       });
        console.log('state----------server');
        console.log(state);
        console.log([state=='false', state==false]);
        $.ajax({
            url: '/inia_members/set_delegation',
            data: {aru_ids: aru_ids, user_id:user_id, state: state},
            type: 'post',
            dataType: "json",
            success: function (data) {
                console.log(data.result)
                if (data.result[0]){
                  $( ".secondary-set-options" ).hide();
                  $('.lcs_checkbox_switch').removeClass('lcs_disabled')
                  $('.notice').show();
                    thi.closest('table').closest('tr').prev().find('span').addClass('test');
                }
                var cls = thi.closest('table').closest('tr').prev().find('span')
                if (data.result[1]){
                    cls.removeClass('green').addClass('red');
                }else{cls.removeClass('red').addClass('green');}
            }
        });
    });
    $('.username').click(function(e){
        e.preventDefault();
        count++;
        sources = []
        var ele = $(this);
         dep_id = $(this).attr('data-dep_id');
         resource = $(this).data('sc');
         inia_project_id = $(this).data('inia_project');
         role_id = $(this).data('role_id');
        cur_user_id = $(this).data('user_id');

        $.ajax({
            url: '/inia_members/project_members',
            dataType: 'json',
            data: {role_id: role_id, project_id: inia_project_id, dep_id:dep_id},
            type: "GET",
            delay: 250,
//        data: {project_id: project_id},
//        data: function (term) {
//          return {
//            term: term,role_id: role_id, project_id: project_id
//          };
//        },
            quietMillis: 50,
            success: function(data) {
                $.each(data.result, function (index, item) {
                    sources.push({
                        'id': item.id,
                        'text': item.text
                    });
                });
                return sources
            }
        });
    });

    $('.username').editable({  //to keep track of selected values in multi select
        url:  '/inia_members/set_approvers',
        source : getSource(),
        params: function(params) {
            params.resource = resource;
            params.ap_role_id = role_id;
            params.inia_project_id = inia_project_id;
            params.project_id = dep_id;
            params.user_id = cur_user_id;
            return params
        },
        display: function(value, sourceData) {
            //display checklist as comma-separated values
            var html = [],
                checked = $.fn.editableutils.itemsByValue(value, getSource(), 'id');
            if(checked.length) {
                $.each(checked, function(i, v) { html.push($.fn.editableutils.escape(v.text)); });
                $(this).html(html.join(', '));
            }
        },
        select2: {
            width: 200,
            placeholder: 'Select User',
            query :getQuery  }
    });

    $('.irConfig').select2({
        placeholder: "Click here to Map with iNia roles.",
        allowClear: true,
        tags: true,
        ajax: {
            url: '/inia_members/inia_roles',
            dataType: 'json',
            data: '',
            type: "GET",
            quietMillis: 50,
            data: function (term) {
                return {
                    term: term,
                    type: 'dept'
                };
            },
            results: function (data) {
                var myResults = [];
                $.each(data.result, function (index, item) {
                    myResults.push({
                        'id': item.id,
                        'text': item.text
                    });
                });
                return {
                    results: myResults
                };
            }
        },
        initSelection: function (item, callback) {
            var id = item.val();
            var text = item.data('option');
            var data = { id: id, text: text };
            callback(data);
        },
        formatSelection: function (item) { return (item.text); },
        escapeMarkup: function (m) { return m; }
    });


    $('.nrConfig').each(function(){
        var role_id = $(this).closest('td').data('role_id');
        var p_id = $(this).closest('td').data('project_id');
        console.log('role_id----------')
        console.log(role_id)
        $(this).select2({
            placeholder: "Click here to Map with iNia roles.",
            allowClear: true,
            tags: true,
            ajax: {
                url: '/inia_members/nanba_approval_roles',
                dataType: 'json',
//                data: {role_id: role_id},
                type: "GET",
                quietMillis: 50,
                data: function (term) {
                    return {
                        term: term,
                        role_id: role_id,
                        project_id: p_id
                    };
                },
                results: function (data) {
                    var myResults = [];
                    $.each(data.result, function (index, item) {
                        myResults.push({
                            'id': item.id,
                            'text': item.text
                        });
                    });
                    return {
                        results: myResults
                    };
                }
            },
            initSelection: function (item, callback) {
                var id = item.val();
                var text = item.data('option');
                var data = { id: id, text: text };
                callback(data);
            },
            formatSelection: function (item) { return (item.text); },
            escapeMarkup: function (m) { return m; }
        });
    });
    //============================================
    $('#tab-Config').click(function(){
        $('.flash').hide();
        inia_mapping_roles();
        nanba_mapping_roles();
    });
    if ($('.irConfig').is(":visible")){
        inia_mapping_roles();
        nanba_mapping_roles();
    }
    function inia_mapping_roles(){
        $('.irConfig').each(function(){
            var thi = $(this)
            var role_id =  thi.closest('td').data('role_id');
            $.ajax({
                url: '/inia_members/inia_roles',
                data: {ar_id: role_id, type:'inia'},
                type: 'get',
                dataType: "json",
                success: function (data) {
                    thi.select2('data', data.result)
                }
            });

        });
    }
    function nanba_mapping_roles(){
        $('.nrConfig').each(function(){
            var thi = $(this)
            var role_id =  thi.closest('td').data('role_id');
            $.ajax({
                url: '/inia_members/nanba_approval_roles',
                data: {ar_id: role_id, type:'nanba'},
                type: 'get',
                dataType: "json",
                success: function (data) {
                    thi.select2('data', data.result)
                }
            });

        });
    }
     $('.irSave').click(function(){
         var row = $(this).closest('tr').find('.irConfig');
         var role_id =  row.closest('td').data('role_id');
         var ids = row.select2('val');
         var n_ids = $(this).closest('tr').find('.nrConfig').select2('val');
         $.ajax({
             url: '/inia_members/map_inia_roles',
             data: {ar_id: role_id, ir_id: ids, nr_ids:n_ids},
             type: 'POST',
             dataType: "json",
             success: function (data) {
                 if(data.result == true){
                     $('.notice').show();
                 }else{$('.error').show();}
             }
         });
     });



//    $.get("../../app/views/inia_members/_user_project_list.html.erb", function(data){
//        $(this).children("div:first").html(data);
//    });
    //================================================================================



    $('.search_dept').attr('disabled', 'true')
  $('.inia_projects').css('max-height',$(window).height()-185).css('overflow','scroll').css('overflow-x','hidden');
//  $('.tab-content').css('max-height',$(window).height()-255).css('overflow','scroll').css('overflow-x','hidden');
    $("#report_container").css('max-height',$(window).height()-255).css('overflow','scroll').css('overflow-x','hidden');
  $('#content').css('min-height', $(window).height()-185)
  $('.user_search,.dept_search,.project_users').css('width','200px');

  $('.dept_search').on("change", function(e) {
    if ($('.dept_search').select2('val') != '') {
      $('.search_dept').removeAttr('disabled')
    }else{$('.search_dept').attr('disabled', 'true')}
  });

  $('.user_search').select2({
    placeholder: "Select a user.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  var query_params = window.location.href.split('?');
  var project = query_params[0].split('/');
  project_id = project[project.length-1]



  $('.project_users').select2({
    placeholder: "Select a user.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term,
          project_id: project_id,
          state: 'dept_user'
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  $('.dept_search').select2({
    placeholder: "Select a Dept.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term,
          type: 'dept'
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  $('.repeat_a').click(function(){
    var nc = $(this).attr('class').split(' ')
    nc = nc[nc.length-1]
    console.log('--------')
    console.log(nc)
    var da = $(this).closest('tr').find('.'+nc).select2('data')
    var data = $(this).closest('tr').nextAll('')
    $.each( data, function( i, l ){
      $(this).find('.'+nc).select2('data',da)
      $(this).find('.config_save').removeAttr('disabled')
      $(this).find('form').append("<input type='hidden' name='a3' value="+ da['id'] +">")
    })
  });

//  $('.repeat_a4').click(function(){
//    var da1 = $(this).closest('tr').find('.name_search_a4').select2('data')
//    var data1 = $(this).closest('tr').nextAll('')
//    $.each( data1, function( i, l ){
//      $(this).find('.name_search_a4').select2('data',da1)
//
//      $(this).find('form').appendTo("<input type='hidden' name='a3' value="+ da1['id'] +">")
//    })
//  });

  $('.config_save').click(function(){
    var cur = $(this)
    var fd = $(this).closest('tr').find('form ').serialize();
    var users = $(this).closest('tr').find('.repeat_a').closest('td').find(".select2-container.user_search")
    var project = $(this).closest('tr').find('td').eq(0).text()
    var st = 1;
    console.log($(this).closest('tr').find('td'));
    $.each( users, function( ) {
      if ($(this).select2('val') == ''){
        st =0
        $('.notification-msg').show();
        $('.notification-msg').html("<li >Approval level was missing in '"+ project.toUpperCase() +"' project please add and continue.</li>")
        return false;
      }
    });
    if (st == 1) {
      $.ajax({
        url: '/inia_members',
        data: fd,
        type: 'POST',
        dataType: "json",
        success: function (data) {
          cur.attr('disabled', 'disabled')
          console.log(data);
        }
      });
    }
  });

  $('.select2-search-choice-close').filter(':visible').change(function(){

  });

  $('.save_all_approver').click(function(){
    var forms = $('.report_tble tr form')
    $.each(forms, function( ) {
      console.log($(this).serialize())
      array_form = $(this).serialize();
      var users = $(this).closest('tr').find('.repeat_a').closest('td').find(".select2-container.user_search")
      var project = $(this).closest('tr').find('td').eq(0).text()
      var st = 1;
      console.log($(this).closest('tr').find('td'));
      $.each( users, function( ) {
        if ($(this).select2('val') == ''){
          st =0
          $('.notification-msg').show();
          $('.notification-msg').html("<li >Approval level was missing in '"+ project.toUpperCase() +"' project please add and continue.</li>")
          return false;
        }
      });

      if (st == 1) {
        $.ajax({
          url: '/inia_members',
          data: array_form,
          type: 'POST',
          async: true,
          dataType: "json",
          success: function (data) {
            console.log(data);
          }
        });
      }else{ return false;}
    });

  });

  $('.user_search, .project_users').on("change", function(e) {
    $(this).closest('tr').find('.config_save').removeAttr('disabled')
    $('.save_all_approver').removeAttr('disabled')
  });
  if ($('.report_tble').is(":visible")){
    $('.save_all_approver').show()
  }
  $('.restricted').select2('disable');
  $('.project_users').click(function(){
    $('#errorExplanation').hide();
  });
  $('.restricted').click(function(){
    $('.flash').hide();
    $('#errorExplanation').show().html("<ul><li>This Role restricted by Nanba Admin</li></ul> ");
    return false;
  });

  $('input[type=button].save_all_approver').click(function(){
    var data = $('#member_role_form').serializeArray();
    $.post("/inia_members/0", data);
  });

});