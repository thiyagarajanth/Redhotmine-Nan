class IniaProject  < ActiveRecord::Base
  has_many :inia_members, :foreign_key => "project_id"
  # has_many :issue_ticket_tag
  has_many :issues, :through => :issue_ticket_tags
  has_many :issue_ticket_tags
  has_many :approval_role_users, :dependent => :destroy, :foreign_key => "inia_project_id"
  has_many :delegation_audits

  def active?
    self.status == 1
  end

end