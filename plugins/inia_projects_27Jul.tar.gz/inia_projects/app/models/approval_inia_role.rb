class ApprovalIniaRole < ActiveRecord::Base
  has_many :inia_roles
  has_many :approval_roles

  class PermissionsAttributeCoder
    def self.load(str)
      str.to_s.scan(/:([a-z0-9_]+)/).flatten.map(&:to_s)
    end

    def self.dump(value)
      YAML.dump(value)
    end
  end

  serialize :inia_role_id, ::ApprovalIniaRole::PermissionsAttributeCoder
  serialize :nanba_approval_role_ids, ::ApprovalIniaRole::PermissionsAttributeCoder

  def inia_role_names
    IniaRole.find(self.inia_role_id)
  end

end