module IniaMembersHelper
  def approval_user(project_id,dept_id, level)
    project = IniaProject.find(project_id)
    members = project.approval_role_users.where(:inia_project_id => project.id)
    roles = []
    members.each do |member|
      if member.approval_role.level == level && member.approval_role.project_id == dept_id
        roles << member.user_id
      end
    end
    if roles.flatten.present?
      return roles[0]
    else
      return nil
    end
  end

  def migrate_app_role_member
    ApprovalRoleIniaMember.all.each do |member|
      p ApprovalRoleUser.count
      if member.inia_member.present?
        role = ApprovalRoleUser.find_or_initialize_by_inia_project_id_and_approval_role_id(member.inia_member.project_id,member.approval_role_id)
        role.user_id = member.inia_member.user_id
        role.project_id = member.approval_role.project_id
        role.save
      end
      p ApprovalRoleUser.count
    end

  end

  def get_deligation_users
    q =  User.current.admin ? "" : "and u.id=#{User.current.id}"
    collect_users =[]
    collect_projects_with_level_query =  "select p.id pr_id,ar.level, aru.approval_role_id as role_id, aru.project_id
    from approval_role_users  aru
    join approval_roles ar on aru.approval_role_id = ar.id
    join inia_projects p on p.id=aru.inia_project_id
    join users u on u.id=aru.primary_user_id
     #{q} group by p.id  order by ar.level desc"
    collect_projects_with_level =  IniaProject.find_by_sql(collect_projects_with_level_query)
    collect_projects_with_level.each do |each_pr|
      find_project_users_with_level_query =  "select u.id,u.login,ar.name,p.name,if(aru.active_user='primary_user','true','false') as active
 from approval_role_users  aru join approval_roles ar on aru.approval_role_id = ar.id join inia_projects p on p.id=aru.inia_project_id
     join users u on u.id=aru.primary_user_id where p.id in (#{each_pr.pr_id}) and ar.level<=#{each_pr.level} and aru.project_id=#{each_pr.project_id} group by u.id order by ar.level desc"
      find_project_users_with_level  =  User.find_by_sql(find_project_users_with_level_query)
      collect_users<< find_project_users_with_level
    end
    collect_users= collect_users.flatten if collect_users.present?
    return collect_users.uniq
  end


end
