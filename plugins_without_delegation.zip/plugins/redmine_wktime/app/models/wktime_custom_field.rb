class WktimeCustomField < CustomField
  def type_name
    :label_wktime
  end
end