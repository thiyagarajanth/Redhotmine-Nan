class ApprovalDefinition < ActiveRecord::Base
  unloadable
  belongs_to :ticket_tag
  has_many :ticket_tags
  belongs_to :approval_role
  belongs_to :interrupter, :class_name => "User", :foreign_key => :interrupter_id
  has_many :issue_approval_details
end
