class RequestRemainder < ActiveRecord::Base
  unloadable
  belongs_to :issue
  belongs_to :ticket_tag
  belongs_to :user
  belongs_to :project

  validates :validity, :presence => true
  validates :project_id, :presence => true
  validates :issue_id, :presence => true
  validates :user_id, :presence => true
  validates :ticket_tag_id, :presence => true


end