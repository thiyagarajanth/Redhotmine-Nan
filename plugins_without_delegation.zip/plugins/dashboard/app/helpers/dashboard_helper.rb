module DashboardHelper

	def get_trackers_for_project (project)
		total_count = Issue.visible.where(:project_id => project).count
		open_count =  Issue.visible.open.where(:project_id => project).count
		return open_count,total_count
	end
end
