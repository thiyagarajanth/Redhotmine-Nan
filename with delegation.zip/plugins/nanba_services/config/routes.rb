# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
match 'tickets/request', :to => 'api_tickets#create', :via => [:get,:post]
match 'tickets/index', :to => 'api_tickets#index', :via => [:get, :post]

match '/mapp/tickets'               => 'mapp/tickets#index', :via => [:get]
match '/mapp/tickets/:id'           => 'mapp/tickets#show', :via => [:get]
match '/mapp/tickets/:id/approve' => 'mapp/tickets#approve', :via => [:put, :post]
match '/mapp/tickets/:id/reject'  => 'mapp/tickets#reject', :via => [:put, :post]
match '/mapp/tickets/:id/clarify' => 'mapp/tickets#clarify', :via => [:put, :post]



