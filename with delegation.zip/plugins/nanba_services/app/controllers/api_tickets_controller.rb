class ApiTicketsController < ApplicationController
  unloadable
  respond_to  :json
  skip_before_filter :verify_authenticity_token

  # skip_before_filter :verify_authenticity_token
  before_filter :find_project_tracker,:only=>[:create]


  def index

  end


  def create
    @messages = []
    @issue = Issue.new
    @issue.project_id=@project.id
    @issue.tracker_id=@tracker.id
    @issue.subject = params[:subject]
    @issue.author_id=@author.id
    @issue.description =params[:description]
    @issue.is_system_created = true
    has_ticket = Redmine::Plugin.registered_plugins.keys.include?(:ticketing_approval_system)
    if has_ticket.present?
      needed_approval = ProjectCategory.find(@category.id).need_approval
    end
  #if !needed_approval || (approval_infos.present? && have_approval) || !approval_infos.present?
    if @issue.save!(:validate => false)
      tag = TicketTag.find_by_name(params[:subject])
      IssueTicketTag.create(:issue_id => @issue.id, :inia_project_id => @for_project.id, :ticket_tag_id => "")
      Issue.set_callback(:create, :after, :send_notification)
      if has_ticket && @issue.tracker.core_fields.include?('approval_workflow')
         project_id = @for_project.id
        if needed_approval && tag.present? && approval_infos.count >= 1
          @issue.ticket_need_approval(approval_infos)
          Mailer.deliver_issue_add(@issue)
        else
          default_assignee =  DefaultAssigneeSetup.find_by_project_id_and_tracker_id(@issue.project_id, @issue.tracker_id)
          default_assignee = default_assignee.present? ? default_assignee : DefaultAssigneeSetup.new
          @issue.assigned_to_id = default_assignee.default_assignee_to
          comments = params[:comment].present? ? params[:comment] : 'Approved'
          journal =  Journal.create(journalized_id: @issue.id, journalized_type: 'Issue', user_id: User.current.id,notes: comments )
          old_status = IssueStatus.find_by_name('waiting for approval')
          status = IssueStatus.find_by_name('open')
          JournalDetail.create(journal_id: journal.id, property: "attr", prop_key: "status_id", old_value: old_status.id, value: status.id)
          @issue.status_id = status.id
          @issue.save
          Mailer.deliver_issue_add(@issue)
        end
      end
      call_hook(:controller_issues_new_after_save, { :params => params, :issue => @issue})
      render_json_ok(@issue)
    else
      render_validation_errors(@issue)
    end
  Issue.set_callback(:create, :after, :send_notification)
  end

  private

  def verify_message_api_key
    if request.present? && request.headers["key"].present?
        find_valid_key = Redmine::Configuration['hrms_api_key'] || File.join(Rails.root, "files")
       (find_valid_key == request.headers["key"].to_s) ? true : render_json_errors("Key Invalid.")
    else
      render_json_errors("Key not found in Url.")
    end
  end

  def find_project_tracker
    errors=[]
    @project = Project.find_by_name("IT Operations")
    @tracker = Tracker.find_by_name("IT Operations")
    if !params[:employeeId].blank?
    author = UserOfficialInfo.find_by_employee_id(params[:employeeId])
    if author.present?
    @author = author.user
    else
      errors << "Employee Id Not found"
    end
    else
      errors << "Employee Id required..!"
    end

    if !params[:project].blank?
    @for_project=IniaProject.find_by_identifier(params[:project])
     unless @for_project
       @for_project=IniaProject.find_by_name(params[:project])
       unless @for_project
       errors << "Project Not Found..!"
      end
     end

    else
      errors << "Project required..!"
    end
    if !params[:category].blank?
    @category =ProjectCategory.find_by_cat_name(params[:category])
    if @category.present? && @category.cat_name!="General Issues"
      errors << "Category Not Found..!"
    end
    unless @category
      errors << "Category Not Found..!"
    end
    else
      errors << "Category required..!"
    end
    if @author.present? && @for_project.present?
     member = IniaMember.find_by_user_id_and_project_id(@author.id,@for_project.id)
        unless member
         @for_project=IniaProject.find_by_name(params[:project])
         if @for_project.present?
           member = IniaMember.find_by_user_id_and_project_id(@author.id,@for_project.id)
           unless member
             errors << "Requested person is not a member of project..!"
           end
         else
           errors << "Requested person is not a member of project..!"
         end

       end
    end
    if errors.present?
      render_json_errors(errors)
    end

  end

  def render_json_errors(errors)
    render :text => errors, :status => 500,:errors=>errors, :layout => nil
  end

  def render_json_ok(issue)
    p '===================== yes ------------'
    render_json_head(issue,"ok")
  end


  def render_json_head(issue,status)
    p '===================== yes --------ko----'
    render :json => {:ticket_id=>issue.id, :status_name => issue.status.name, :updated_on => issue.updated_on}, :status => 200, :layout => nil
  end


end
