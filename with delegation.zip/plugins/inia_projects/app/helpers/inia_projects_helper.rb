module IniaProjectsHelper
  def inia_projects_settings_tabs
    # if User.current.admin? || User.current.projects_by_role.keys.map(&:permissions).flatten.include?(:nanba_config)
      tabs = [{:name => 'projects',  :partial => 'inia_members/project_list', :label => :label_projects},
              {:name => 'delegation', :partial => 'inia_members/delegation', :label => :label_delegate},
      ]
      if User.current.admin?
    tabs << {:name => 'Config', :partial => 'inia_members/config', :label => :label_config}
      end
    tabs
    # else
    #   tabs = [{:name => 'projects',  :partial => 'inia_members/projects', :data=>'p', :label => :label_projects},
    #   ]
    # end
  end
end
