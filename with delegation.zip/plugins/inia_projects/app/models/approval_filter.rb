class ApprovalFilter < ActiveRecord::Base
  belongs_to :user
  serialize :project_id

  before_save :check_filter

  def check_filter
    if self.project_id.length == 0
      self.project_id = ['215']
    end
  end
end