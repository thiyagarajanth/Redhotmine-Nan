class IniaMemberNanbaRole < ActiveRecord::Base
  belongs_to :inia_member
  belongs_to :role
end
