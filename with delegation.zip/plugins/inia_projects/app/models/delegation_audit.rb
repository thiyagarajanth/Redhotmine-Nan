class DelegationAudit < ActiveRecord::Base
  # attr_accessible :title, :body
  belongs_to :inia_projects
  belongs_to :projects
  belongs_to :approval_roles
  belongs_to :users
  belongs_to :approval_role_user
end