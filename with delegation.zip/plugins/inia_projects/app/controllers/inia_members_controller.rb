class String
  def to_nil
    present? ? self : nil
  end
end
class IniaMembersController < ApplicationController
  unloadable
  skip_before_filter :authorize
  skip_before_filter :check_delegated_user

  def index
    @dept=[]
    @depts=[]
    # apr_ids = ApprovalRoleUser.where(:primary_user_id => User.current.id).map(&:approval_role_id).uniq
    af = ApprovalFilter.find_or_initialize_by_user_id(User.current.id)
    p '======af ===='
    p af
    if af.id.nil?
      af.project_id=['215']
      af.save
    end
    if params[:commit].present?
      af.project_id = params[:project_ids].present? ? params[:project_ids] : []
      af.save
    end
    Project.all.collect{|rec|
     # if User.current.admin?
        @dept << rec if rec.approval_roles.present?
        @depts << rec if rec.approval_roles.present? && (af.id.present? ? af.project_id.include?(rec.id.to_s) : false)
      # else
      #   # (apr_ids & rec.approval_roles.map(&:id)).empty?
      #   @dept << rec if rec.approval_roles.present? && rec.approval_roles.where(:can_restrict => false).count > 0
    #  end
    }
    project_ids =  ApprovalRoleUser.where(:primary_user_id => User.current.id).map(&:inia_project_id).uniq
    if User.current.admin?
      @projects = IniaProject.where(:status => 1).order('name asc')
    else
      @projects = IniaProject.where(:id => project_ids, :status => 1).order('name asc')
    end
    render 'index'
  end

  def project_members
    users = []
    # if params[:project_id].present?
      ap = ApprovalRole.find(params[:role_id])
      if ap.present? && ap.can_restrict?
        users = User.find_by_sql("select u.id,u.firstname, u.lastname from users as u where u.status=1 and type='User' and (u.firstname like '%#{params[:term]}%' or u.lastname like '%#{params[:term]}%')  order by u.firstname").collect{|rec| {id:rec.id, text:rec.firstname+' '+rec.lastname} }
      elsif params[:project_id].present?
        air = ApprovalIniaRole.find_by_approval_role_id(params[:role_id]) rescue nil
        if air.present?
          q = "inia_member_roles.role_id in (#{air.inia_role_id.join(',')}) and "
        else
          q = "inia_member_roles.role_id=0 and "
        end
        user_ids = IniaMember.joins(:inia_member_roles).where("#{q} inia_members.project_id=#{params[:project_id]}" ).map(&:user_id)
        user_ids << ApprovalRoleUser.where(:inia_project_id => params[:project_id],:project_id => params[:dep_id], :approval_role_id => air.nanba_approval_role_ids).map(&:primary_user_id) if air.present? && air.nanba_approval_role_ids.present?
        cod = params[:term].present? ? "and (u.firstname like '%#{params[:term]}%' or u.lastname like '%#{params[:term]}%')" : ''
        users = User.active.find_by_sql("select u.id,u.firstname, u.lastname from users as u where u.status=1 and type='User' and u.id in (#{user_ids.flatten.join(',')}) "+cod+" order by u.firstname").collect{|rec| {id:rec.id, text:rec.firstname+' '+rec.lastname} } if user_ids.present?
      end
    # end
    render :json => {result: users }
  end

  def set_approvers
    if params['resource'] == 'restrict' || params['resource'] == 'restrict' && params['type'] == 'date'
      # ApprovalRoleUser.where(:primary_user_id => params['user_id'], :inia_project_id => params['inia_project_id']).update_all(:secondary_user_id => params['value'])
      if params['name'] == 'active_till'
        ApprovalRoleUser.where(:primary_user_id => params['user_id'], :project_id => params['project_id']).update_all(:active_till => Date.parse(params['value'])) if params['type'] == 'date'
      elsif params['name'] == 'active_from'
        ApprovalRoleUser.where(:primary_user_id => params['user_id'], :project_id => params['project_id']).update_all(:active_from => Date.parse(params['value'])) if params['type'] == 'date'
      end
      ApprovalRoleUser.where(:primary_user_id => params['user_id'], :project_id => params['project_id']).update_all(:secondary_user_id => params['value']) if !params['type'].present?
    elsif params['resource'].present?
      if params['resource']=='date'
        users = ApprovalRoleUser.where(:inia_project_id => params['inia_project_id'],:primary_user_id => params['user_id'] )
        users.update_all(:active_till => Date.parse(params['value'])) if params['name'] == 'active_till'
        users.update_all(:active_from => Date.parse(params['value'])) if params['name'] == 'active_from'
      else
        ar = ApprovalRoleUser.find_or_initialize_by_approval_role_id_and_inia_project_id_and_project_id(params['ap_role_id'], params['inia_project_id'], params['project_id'])
        if params['resource']=='primary'
          ar.primary_user_id = params['value']
        elsif params['resource']=='secondary'
          ar.secondary_user_id = params['value']
        end
        ar.save
      end
    end
    render :json => {result: params }
  end

  def applyall_approvers
    if params["applyall"].present?
      approvers = params["applyall"]
      secondary = approvers['0']
      rec = ApprovalRoleUser.where(:primary_user_id => secondary['user_id'], :project_id => secondary['dept_id']).last
      dep_ids = approvers.values.map{|x| x['dept_id']}
      if secondary['type'] == 'secondary'
        p '============== 1 ============='
        ApprovalRoleUser.where(:primary_user_id => secondary['user_id'], :project_id => dep_ids).update_all(:secondary_user_id => rec.secondary_user_id)
      elsif secondary['type'] == 'date'
        if secondary['resource']== 'secondary'
          inia_ids = approvers.values.map{|x| x['inia_project']}
          aru = ApprovalRoleUser.where(:primary_user_id => secondary['user_id'], :inia_project_id => inia_ids)
        elsif secondary['resource']== 'restrict'
          aru = ApprovalRoleUser.where(:primary_user_id => secondary['user_id'], :project_id => dep_ids)
        end
        aru.update_all(:active_till => Date.parse(secondary['date']) ) if secondary['data']=='active_till'
        aru.update_all(:active_from => Date.parse(secondary['date'])) if secondary['data']=='active_from'
      end
    end
    render :json => { result: true }

  end

  def inia_roles
    roles = []
    if params['ar_id'].present?
      rec = ApprovalIniaRole.find_by_approval_role_id(params['ar_id']) rescue nil
      IniaRole.find(rec.inia_role_id).map{|p| roles << {id:p.id, text:p.name} } if rec.present?
    else
      con = params[:term].present? ? "name like '%#{params[:term]}%'" : 'id > 0'
      IniaRole.where(con).each do |role|
        roles << {id:role.id, text:role.name} if !role.permissions.empty?
      end
    end
    render :json => {result: roles }
  end

  def nanba_approval_roles
    roles = []
    if params['ar_id'].present?
      rec = ApprovalIniaRole.find_by_approval_role_id(params['ar_id']) rescue nil
      ApprovalRole.find(rec.nanba_approval_role_ids).map{|p| roles << {id:p.id, text:p.name} } if rec.present?
    elsif params['role_id'].present?
      rec = ApprovalRole.find(params['role_id'])
      con = params[:term].present? ? "project_id=#{params['project_id']} and name like '%#{params[:term]}%'" : "project_id=#{params['project_id']}"
      ApprovalRole.where(con).map{|p| roles << {id:p.id, text:p.name} } if rec.present?
    end
    render :json => {result: roles }
  end

  def map_inia_roles
    air = ApprovalIniaRole.find_or_initialize_by_approval_role_id(params['ar_id'])
    roles = IniaRole.find(params['ir_id'])
    air.inia_role_id = roles.map!{|c| c.id.to_s.to_sym}
    air.nanba_approval_role_ids = params['nr_ids'].map!{|c| c.to_sym} if  params['nr_ids'].present?
    render :json => {result: air.save }
  end

  def get_project_list
    @user = User.find(params[:user_id])
    @departments=[]; Project.all.collect{|rec|  @departments << rec if rec.approval_roles.present?}
    query_to_list_projects = "select u.id,u.login,ar.name,p.name,p.id as pr_id,aru.id,ar.level,aru.approval_role_id,aru.project_id dep_id
,group_concat(dep_p.id,':',ar.id,':',ar.name,':',ar.level,':',(select if(aru1.secondary_user_id is not NULL,aru1.secondary_user_id,0)
from approval_role_users aru1 where aru1.approval_role_id=aru.approval_role_id
and aru1.project_id=aru.project_id and aru1.inia_project_id=aru.inia_project_id  limit 1),':',aru.id) as ap_roles
,group_concat(if(ar.can_restrict=true,true,false)) as can_restrict
from approval_role_users  aru
join approval_roles ar on aru.approval_role_id = ar.id
join inia_projects p on p.id=aru.inia_project_id
join users u on u.id=aru.primary_user_id
join projects dep_p on dep_p.id=aru.project_id
and u.id=#{params[:user_id]} group by aru.inia_project_id  order by ar.level desc  "

    projects = Project.find_by_sql(query_to_list_projects)
    render :json => { :attachmentPartial => render_to_string('inia_members/_user_project_list', :layout => false, :locals => { :projects => projects }) }
  end

  def set_delegation
    restrict = params['restrict']
    user_id = params['delegaters']['0']['user_id']
    dep_ids = params['delegaters'].values.map{|x| x['dep_id']}
    aru_ids = params['delegaters'].values.map{|x| x['aru_ids']}
    if restrict == 'true'
      ids = ApprovalRoleUser.where(:project_id => dep_ids, :primary_user_id =>user_id).map(&:id)
    else
      ids = aru_ids
    end
    status = IssueStatus.find_by_name('waiting for approval')
    if params['state']=='on'
      aru =  ApprovalRoleUser.where("id in (#{ids.join(',')}) and secondary_user_id is not NULL and DATE(active_from) <= CURDATE()")
      # aru.update_all(:active_user => 'secondary_user', :updated_by => User.current.id) if aru.present?
      aru.each do |ar|
        next if ar.active_user == 'secondary_user'
        issue_ids = IssueTicketTag.where(:inia_project_id => ar.inia_project_id).map(&:issue_id)
        issues = Issue.where(:status_id => status.id,:id => issue_ids, :assigned_to_id => ar.primary_user_id)
        count = issues.count
        DelegationAudit.create(:inia_project_id => ar.inia_project_id, :project_id => ar.project_id, :approval_role_id =>ar.approval_role_id,
                               :primary_user_id => ar.primary_user_id, :secondary_user_id => ar.secondary_user_id, :delegated_by => User.current.id,
                               :from_date => ar.active_from, :to_date => ar.active_till, :status => true,:is_auto_delegation => false, :approval_role_user_id => ar.id)
        ar.update_attributes(:active_user => 'secondary_user', :updated_by => User.current)
        issues.each do |issue|
          issue.init_journal(User.current, 'Delegation of approver has been activated. Tickets has been assigned to secondary approver. ')
          issue.assigned_to_id = ar.secondary_user_id
          issue.save
        end
        Mailer.delegation_remainder(ar.secondary_user_id,ar.primary_user_id, count, ar).deliver
      end
    else
      aru = ApprovalRoleUser.where("id in (#{ids.join(',')}) ")
      # aru.update_all(:active_user => 'primary_user', :active_from=> nil, :active_till => nil)
      aru.each do |ar|
        next if ar.active_user == 'primary_user'
        DelegationAudit.create(:inia_project_id => ar.inia_project_id, :project_id => ar.project_id, :approval_role_id =>ar.approval_role_id,
                               :primary_user_id => ar.primary_user_id, :secondary_user_id => ar.secondary_user_id, :delegated_by => User.current.id,
                               :from_date => ar.active_from, :to_date => ar.active_till, :status => false, :is_auto_delegation => false, :approval_role_user_id => ar.id)
        ar.update_attributes(:active_user => 'primary_user', :active_from=> nil, :active_till => nil, :updated_by => User.current)
        issue_ids = IssueTicketTag.where(:inia_project_id => ar.inia_project_id).map(&:issue_id)
        issues = Issue.where(:status_id => status.id, :assigned_to_id => ar.secondary_user_id, :id => issue_ids)
        count = issues.count
        issues.each do |issue|
          issue.init_journal(User.current, 'Delegation of approver has been activated. Tickets has been assigned to Primary approver. ')
          issue.assigned_to_id = ar.primary_user_id
          issue.save
        end
        Mailer.delegation_remainder(ar.primary_user_id, ar.secondary_user_id, count, ar).deliver
      end
    end
    aru = ApprovalRoleUser.where(:active_user => 'secondary_user', :primary_user_id => user_id)
    render :json => {result: [true, (aru.count > 0 ? 'on' : 'off')] }
  end

end