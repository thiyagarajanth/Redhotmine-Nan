module IniaProject
  module Infectors
    module Mailer
      module ClassMethods ;end
      module InstanceMethods;  end
      def self.included(receiver)
        def delegation_remainder(primary, secondary, count, ar)
          users = Principal.find([primary, secondary])
          @tickets_url = url_for(:controller => 'issues', :action => 'index',  "set_filter"=>"1", "f"=>["status_id", ""], "op"=>{"status_id"=>"="}, "v"=>{"status_id"=>["37"]}, "c"=>["subject", "author", "assigned_to", "priority", "status", "created_on", "updated_on"], "group_by"=>"", "project_id"=>"itops")
          @primary = users.first
          @secondary = users.last
          @user = User.current.present? ? Principal.find(User.current.id).name : 'Nanba Admin'
          @count = count
          @from_date = ar.active_from.strftime("%d-%b-%Y") rescue nil
          @to_date = ar.active_till.strftime("%d-%b-%Y") rescue nil
          mail(:to => @primary.mail,:cc => @secondary.mail, :subject => "Nanba Delegation Notification ")
        end
      end
  	end
  end
end