module IniaProject
  module Infectors
    module User
      module ClassMethods; end

      module InstanceMethods; end

      def self.included(receiver)
        receiver.extend(ClassMethods)
        receiver.send(:include, InstanceMethods)
        receiver.class_eval do
          unloadable
          has_many :inia_member_roles, :dependent => :destroy, :foreign_key => "user_id"
          has_many :delegation_audits
          has_many :approval_role_users
          has_one :approval_filter

        end
      end

    end
  end
end