
$(document).ready(function(){
    $('#tab-projects').click(function(){
        setTable();
    });
    setTable();
    function setTable(){
        $('.container2 .list:eq(1) tr').each(function(index, item) {
            var newindex = index+1;
            if(index==0){
              $('.container1  tr:eq(0) th:first').innerHeight($('.container2 .list:eq(0) thead').outerHeight()-2);
            }
            $('.container1  tr:eq(' + newindex + ') th').innerHeight($(item).find('> td:eq(0)').outerHeight()-2);
        });
    }


    (function($) {
        $.fn.hasScrollBar = function() {
            return this.get(0).scrollHeight > this.height();
        }
    })(jQuery);
    console.log($('.table-body').hasScrollBar()==true)
    if ($('.table-body').hasScrollBar()){
        $('.table-header').css('width', "98.8%")
    }
    //========================

    var count = 4, sources = [], resource = '', inia_project_id='', role_id='', dep_id = '', cur_user_id='';
    var getSource = function() {
        return JSON.parse(JSON.stringify(sources));
    };

    var getQuery = function(options){
        options.callback({ results : sources });
    };
    tds = [];
    var table = $('.secondary-set-options tr:visible').not(':first').not(':last');
    table.each(function(){
        tds.push($(this).find('td').length)
    });
    var td_len =Math.max.apply(Math,tds);
    table.each(function(){
       var remain =  td_len - $(this).find('td').length;
        console.log([td_len , $(this).find('td').length])
        if (remain > 0){
            var i = remain;
            while (i--) {
               $(this).append("<td></td>")
            }
        }

    });

//=====================================================================
    // --------------delegate check all ---------
//    $(document).on('click', '.delegate_all:visible', function(){
    $('.delegate_all').on('click',function(){
        var thi = $(this)


        var table1= $(this).closest('table');
//        var uncheck_count = table1.find("input:checkbox:not(:checked)").length;
        table1.find('td input:checkbox').each(function(){
            var from =  $(this).closest('tr').find('#active_from').text();
            var to = $(this).closest('tr').find('#active_till').text()//.editable('getValue')['active_till'];
            console.log('----------1----*******************************************----1---')
//            console.log([from ,to,$('.delegate_all').attr('state') == 'off' , uncheck_count > 0 ])
            if (from != 'none' && to != 'none') {
                if (thi.attr('state') == 'off' ) {
                    console.log('----------2--------1---')
                    $(this).attr('state', 'on');
                    $(this).prop('checked', true);
                } else {
                    console.log('----------3---')
                    $(this).attr('state', 'off');
                    $(this).prop('checked', false);
                }
            }


        });
        if (thi.attr('state')=='on'){
            thi.attr('state', 'off');
        }else{thi.attr('state', 'on');}
        console.log(thi.attr('state'))
        checkDelegation(this);
        return false
    });
    //======================================
    $('input[data-delegated]').on('click', function(event) {
        var from = $(this).closest('tr').find('#active_from').editable('getValue')['active_from'];
        var to = $(this).closest('tr').find('#active_till').editable('getValue')['active_till'];
        console.log([from == undefined, from])
        if (from == undefined){
            alert("Please select 'Active From' date.");
            event.preventDefault();
            event.stopPropagation();
            return false;

        }
        if (to == undefined){
            alert("Please select 'Active Till' date.");
            event.preventDefault();
            event.stopPropagation();
            return false;
            alert('Break');
        }


    });

     $("input[data-delegated]").on('change', function(event){

         checkDelegation(this);
     });

    function checkDelegation(thi){
//        console.log('----------2-----------')

        var baseTable = $(thi).closest('table');
        var de =  baseTable.find("input[data-delegated='true']:checked").length;
        var ce = baseTable.find("input[data-delegated='false']:checked").length;
        var se =  baseTable.find("input[data-delegated]:checked").length;
        if (de>0 && ce<1 ){
            baseTable.find("input[value='Stop Delegate']").attr('disabled', false);
            baseTable.find("input[value='Start Delegate']").attr('disabled', true);
        }
        if (ce>0 && de<1){
            baseTable.find("input[value='Stop Delegate']").attr('disabled', true);
            baseTable.find("input[value='Start Delegate']").attr('disabled', false);
        }
        if ((ce>0 && de>0) || se <1){
            baseTable.find("input[value='Stop Delegate']").attr('disabled', true);
            baseTable.find("input[value='Start Delegate']").attr('disabled', true);
        }
    }

    //------------------------Delegate-----------------------
    $('.delegate').click(function(){
        var thi = $(this);
        var user_id = thi.data('user_id');
        var state = thi.closest('.secondary-set-options').attr('state');
        var aru_ids = [];
        var data1 = {};
        if ($(this).data('restricted')){
            var checked = $(this).closest('table').find("input:checkbox:checked");
            var restrict_delegation=[];
            checked.each(function(){
                $(this).closest('tr').find('.username').map(function() { restrict_delegation.push({dep_id:$(this).data('dep_id'),resource: $(this).data('sc'), user_id:$(this).data('user_id')}) }).get()
            });
            data1 = {restrict: true, delegaters: restrict_delegation, state: 'on'}
        }else{
//            $('.delegated_user_row').each(function(){
//                aru_ids.push($(this).find('.username').map(function() { return $(this).data('aru_id') }).get())
//            });
            var checked2 = $(this).closest('table').find("input:checkbox:checked");
            console.log(checked2.length)
            console.log('checked2.length')
            var delegation=[];
            checked2.each(function(){
                $(this).closest('tr').find('.username').map(function() { delegation.push({dep_id:$(this).data('dep_id'),resource: $(this).data('sc'), user_id:$(this).data('user_id'), aru_ids:$(this).data('aru_id') }) }).get()
            });

            data1 = {restrict: false,delegaters: delegation, state: 'on'}
        }
        $.ajax({
            url: '/inia_members/set_delegation',
            data: data1,
            type: 'post',
            dataType: "json",
            success: function (data) {
                console.log(data.result)
                if (data.result[0]){
                  $( ".secondary-set-options" ).hide();
                  $('.lcs_checkbox_switch').removeClass('lcs_disabled')
                  $('.notice').show();
                    thi.closest('table').closest('tr').prev().find('span').addClass('test');
                }
                var cls = thi.closest('table').closest('tr').prev().find('span')
                console.log('=====clof---')
                console.log(data.result[1] == 'off')
                if (data.result[1]=='on'){
                    cls.removeClass('silver').addClass('green');
                    thi.closest('table').closest('tr').prev().find('.switch1').lcs_on();
                }else{
                    cls.removeClass('green').addClass('silver');
                    thi.closest('table').closest('tr').prev().find('.switch1').lcs_off();
                }

            }
        });
    });
    //====================Re-delegate===========================
    $('.redelegate').click(function(){
        var thi = $(this);
        var user_id = thi.data('user_id');
        var state = thi.closest('.secondary-set-options').attr('state')
        var aru_ids = [];
        var data1 = {};
        if ($(this).data('restricted')){
            var checked = $(this).closest('table').find("input:checkbox:checked")
            var restrict_delegation=[]
            checked.each(function(){
                $(this).closest('tr').find('.username').map(function() { restrict_delegation.push({dep_id:$(this).data('dep_id'),resource: $(this).data('sc'), user_id:$(this).data('user_id')}) }).get()
            });
            data1 = {restrict: true, delegaters: restrict_delegation, state: 'off'}
        }else{
            var checked2 = $(this).closest('table').find("input:checkbox:checked");
            console.log(checked2.length)
            console.log('checked2.length')
            var delegation=[];
            checked2.each(function(){
                $(this).closest('tr').find('.username').map(function() { delegation.push({dep_id:$(this).data('dep_id'),resource: $(this).data('sc'), user_id:$(this).data('user_id'), aru_ids:$(this).data('aru_id') }) }).get()
            });

            data1 = {restrict: false,delegaters: delegation, state: 'off'}
        }
        $.ajax({
            url: '/inia_members/set_delegation',
            data: data1,
            type: 'post',
            dataType: "json",
            success: function (data) {
                console.log(data.result)
                if (data.result[0]){
                    $( ".secondary-set-options" ).hide();
                    $('.lcs_checkbox_switch').removeClass('lcs_disabled')
                    $('.notice').show();
                    thi.closest('table').closest('tr').prev().find('span').addClass('test');
                }
                var cls = thi.closest('table').closest('tr').prev().find('span')
//                if (data.result[1]){
//                    cls.removeClass('silver').addClass('green');
//                }else{cls.removeClass('green').addClass('silver');}
                console.log('----------------da')
                console.log(data.result[2])
                if (data.result[1] == 'on'){
                    cls.removeClass('silver').addClass('green');
                    thi.closest('table').closest('tr').prev().find('.switch1').lcs_on();
                }else{
                    cls.removeClass('green').addClass('silver');
                    thi.closest('table').closest('tr').prev().find('.switch1').lcs_off();
                }
            }
        });
    });
    //======================================================================================
    $('.username').click(function(e){
        e.preventDefault();
console.log('========keypress-----')
        count++;
        sources = [];
        var ele = $(this);
         dep_id = $(this).attr('data-dep_id');
         resource = $(this).data('sc');
         inia_project_id = $(this).data('inia_project');
         role_id = $(this).data('role_id');
        cur_user_id = $(this).data('user_id');

        $.ajax({
//            url: "/inia_members/project_members?role_id="+role_id+"&project_id="+inia_project_id+"&dep_id="+dep_id,
            url: "/inia_members/project_members",
            dataType: 'json',
            data: {role_id: role_id, project_id: inia_project_id, dep_id:dep_id, resource:resource },
            type: "GET",
            delay: 250,
//        data: {project_id: project_id},
//            data: function (term, page) {
//                console.log('----------search ----------------------');
//                return {
//                    role_id: role_id, project_id: inia_project_id, dep_id:dep_id, resource:resource , q: term //search term
//                };
//            },
            quietMillis: 50,
            success: function(data) {
                $.each(data.result, function (index, item) {
                    sources.push({
                        'id': item.id,
                        'text': item.text
                    });
                });
                return sources
            }
        });
    });

    $('.username').editable({  //to keep track of selected values in multi select
        url:  '/inia_members/set_approvers',
        source : getSource(),
        inputclass: 'input-medium privacy-select',
        validate: function(value) {
console.log('==============================================yes----')
            console.log([value,$(this).text(), value === ''])
            if (value === null ||  (value === '' && $(this).text()=='none') ) {
                    return 'Please select a user.';

            }
        },
        showbuttons: false,
        params: function(params) {
            console.log('params------');
            console.log(params)
//            params.resource = resource;
//            params.ap_role_id = role_id;
//            params.inia_project_id = inia_project_id;
//            params.project_id = dep_id;
//            params.user_id = cur_user_id;

            params.ap_role_id = $(this).editable().data('role_id');
            params.resource = $(this).editable().data('sc');
            params.project_id = $(this).editable().data('dep_id');
            params.user_id = $(this).editable().data('user_id');
            params.inia_project_id = $(this).editable().data('inia_project');



            return params
        },
        display: function(value, sourceData) {
            //display checklist as comma-separated values
            var html = [],
                checked = $.fn.editableutils.itemsByValue(value, getSource(), 'id');
            if(checked.length) {
                $.each(checked, function(i, v) { html.push($.fn.editableutils.escape(v.text)); });
                $(this).html(html.join(', '));
            }
        },
        select2: {
            width: '200px',
            placeholder: 'Select User',
            query :getQuery,
            ajax: {

            }
        }
    });


    //=============================================================================
    //---------------------------------------------------------------------------------

    $('.irConfig').select2({
        placeholder: "Click here to Map with iNia roles.",
        allowClear: true,
        tags: true,
        ajax: {
            url: '/inia_members/inia_roles',
            dataType: 'json',
            data: '',
            type: "GET",
            quietMillis: 50,
            data: function (term) {
                return {
                    term: term,
                    type: 'dept'
                };
            },
            results: function (data) {
                var myResults = [];
                $.each(data.result, function (index, item) {
                    myResults.push({
                        'id': item.id,
                        'text': item.text
                    });
                });
                return {
                    results: myResults
                };
            }
        },
        initSelection: function (item, callback) {
            var id = item.val();
            var text = item.data('option');
            var data = { id: id, text: text };
            callback(data);
        },
        formatSelection: function (item) { return (item.text); },
        escapeMarkup: function (m) { return m; }
    });

function load_nanba_roles(){
    $('.nrConfig').each(function(){
        var role_id = $(this).closest('td').data('role_id');
        var p_id = $(this).closest('td').data('project_id');
        console.log('role_id----------')
        console.log(role_id)
        $(this).select2({
            placeholder: "Click here to Map with Nanba Approval levels.",
            allowClear: true,
            tags: true,
            ajax: {
                url: '/inia_members/nanba_approval_roles',
                dataType: 'json',
//                data: {role_id: role_id},
                type: "GET",
                quietMillis: 50,
                data: function (term) {
                    return {
                        term: term,
                        role_id: role_id,
                        project_id: p_id
                    };
                },
                results: function (data) {
                    var myResults = [];
                    $.each(data.result, function (index, item) {
                        myResults.push({
                            'id': item.id,
                            'text': item.text
                        });
                    });
                    return {
                        results: myResults
                    };
                }
            },
            initSelection: function (item, callback) {
                var id = item.val();
                var text = item.data('option');
                var data = { id: id, text: text };
                callback(data);
            },
            formatSelection: function (item) { return (item.text); },
            escapeMarkup: function (m) { return m; }
        });
    });
}
    //============================================
    $('#tab-Config').click(function(){
        $('.flash').hide();
        inia_mapping_roles();
        nanba_mapping_roles();
        load_nanba_roles();
    });
    if ($('.irConfig').is(":visible")){
        inia_mapping_roles();
        nanba_mapping_roles();
        load_nanba_roles();
    }
    function inia_mapping_roles(){
        $('.irConfig').each(function(){
            var thi = $(this)
            var role_id =  thi.closest('td').data('role_id');
            $.ajax({
                url: '/inia_members/inia_roles',
                data: {ar_id: role_id, type:'inia'},
                type: 'get',
                dataType: "json",
                success: function (data) {
                    thi.select2('data', data.result)
                }
            });

        });
    }
    function nanba_mapping_roles(){
        $('.nrConfig').each(function(){
            var thi = $(this)
            var role_id =  thi.closest('td').data('role_id');
            $.ajax({
                url: '/inia_members/nanba_approval_roles',
                data: {ar_id: role_id, type:'nanba'},
                type: 'get',
                dataType: "json",
                success: function (data) {
                    thi.select2('data', data.result)
                }
            });

        });
    }
     $('.irSave').click(function(){
         var row = $(this).closest('tr').find('.irConfig');
         var role_id =  row.closest('td').data('role_id');
         var ids = row.select2('val');
         var n_ids = $(this).closest('tr').find('.nrConfig').select2('val');
         $.ajax({
             url: '/inia_members/map_inia_roles',
             data: {ar_id: role_id, ir_id: ids, nr_ids:n_ids},
             type: 'POST',
             dataType: "json",
             success: function (data) {
                 if(data.result == true){
                     $('.notice').show();
                 }else{$('.error').show();}
             }
         });
     });



//    $.get("../../app/views/inia_members/_user_project_list.html.erb", function(data){
//        $(this).children("div:first").html(data);
//    });

    $('.repeat_b').click(function(e){
        var ap_all = [];
        var edit = $(this).closest('td').find('.username')
        var userName = edit.text();
        //==========
        var dept = edit.data('dep_id');
        var cur_user_id = edit.data('user_id');
        var resource = edit.data('sc');
        //==========
        ap_all.push({ dept_id:dept, user_id:cur_user_id, resource:resource, type:'secondary'  });
        $(this).closest('table').find('tr .username').each(function(){
            if ($(this).closest('tr').find("input[data-delegated='true']").length==0){
                var dept = $(this).data('dep_id');
                var cur_user_id = $(this).data('user_id');
                var resource = $(this).data('sc');
                ap_all.push({ dept_id:dept,user_id:cur_user_id, resource:resource });
                $(this).text(userName);
            }

        });
        if ($(this).closest('tr').find("input[data-delegated='true']").length == 0) {
            $.ajax({
                url: '/inia_members/applyall_approvers',
                data: { applyall: ap_all},
                type: 'POST',
                dataType: "json",
                success: function (data) {
                    if (data.result == true) {
                        $('.notice').show();
                    } else {
                        $('.error').show();
                    }
                }
            });
        }
    });
    //============== repeat date till =============
    $('.repeat_active').click(function(){

        var ap_all = [];
        var edit = $(this).closest('tr').find('.username');
        //==========
        var dept = edit.data('dep_id');
        var cur_user_id = edit.data('user_id');
        var resource = edit.data('sc');

        var state = $(this).data('active');
        //==========
        var curDate = $(this).closest('td').find('#'+state).text();
        console.log('===========yes=====')
        ap_all.push({ dept_id:dept, user_id:cur_user_id, resource:resource, date:curDate, type:'date',data:state });
        $(this).closest('table').find('tr #'+state).each(function(){
            if ($(this).closest('tr').find("input[data-delegated='true']").length==0) {
                var dept = $(this).data('dep_id');
                var cur_user_id = $(this).data('user_id');
                var resource = $(this).data('sc');
                var inia_project = $(this).data('inia_project');
                ap_all.push({ dept_id: dept, user_id: cur_user_id, resource: resource, date: curDate, inia_project:inia_project });
                $(this).text(curDate);
            }
        });
        if($(this).closest('tr').find("input[data-delegated='true']").length == 0) {
            $.ajax({
                url: '/inia_members/applyall_approvers',
                data: { applyall: ap_all},
                type: 'POST',
                dataType: "json",
                success: function (data) {
                    if (data.result == true) {
                        $('.notice').show();
                    } else {
                        $('.error').show();
                    }
                }
            });
        }
    });
    //-------------------------------end----------------
    //============= repeat date from ==============
//    $('.repeat_active_from').click(function(){
//        var ap_all = [];
//        var edit = $(this).closest('tr').find('.username');
//        var curDate = $(this).closest('td').find('#active_from').text();
//        //==========
//        var dept = edit.data('dep_id');
//        var cur_user_id = edit.data('user_id');
//        var resource = edit.data('sc');
//        //==========
//        ap_all.push({ dept_id:dept, user_id:cur_user_id, resource:resource, date:curDate, type:'date',data:'active_from' });
//        $(this).closest('table').find('tr #active_from').each(function(){
//            var dept = $(this).data('dep_id');
//            var cur_user_id = $(this).data('user_id');
//            var resource = $(this).data('sc');
//            ap_all.push({ dept_id:dept,user_id:cur_user_id, resource:resource, date:curDate });
//            $(this).text(curDate);
//        });
//        $.ajax({
//            url: '/inia_members/applyall_approvers',
//            data: { applyall: ap_all},
//            type: 'POST',
//            dataType: "json",
//            success: function (data) {
//                if(data.result == true){
//                    $('.notice').show();
//                }else{$('.error').show();}
//            }
//        });
//    });

    //-------------------------------end----------------
    $(function(){
        $('.activeDuration').editable({
            format: 'dd-mm-yyyy',
            viewformat: 'dd-mm-yyyy',
            datepicker: {
                firstDay: 3,
                startDate: '0'
            },
            showbuttons: false,
            validate: function(value) {
                if ($(this).attr('id')=='active_till'){
                    try {
                        from= $(this).closest('td').prev('td').find('#active_from').editable('getValue')['active_from'].split("-");
                    }
                    catch(err) {
                        from = ''
                    }
                    console.log(from[2], from[1] - 1, from[0]);
                    console.log(value , new Date(from[2], from[1] - 1, from[0]));
                    if (value <= new Date(from[2], from[1] - 1, from[0])) {
                        return 'Date should be grater then or equal to Active from. ';
                    }
                }
                if ($(this).attr('id')=='active_from'){
                    try {
                        from= $(this).closest('td').next('td').find('#active_till').editable('getValue')['active_till'].split("-");
                    }
                    catch(err) {
                        from = ''
                    }
                    var d = new Date(value);
                    var curr_date = d.getDate();
                    var curr_month = d.getMonth();
                    var curr_year = d.getFullYear();
                    curr_year = curr_year.toString();
                    var valueDate = new Date(parseInt(curr_year),curr_month,curr_date);
                    console.log([valueDate , new Date(from[2], from[1] - 1, from[0]), valueDate >= new Date(from[2], from[1] - 1, from[0])]);
                    if (valueDate > new Date(from[2], from[1] - 1, from[0])) {
                        return 'Date should be Less then or equal to Active till. ';
                    }
                }
                if (value === null ) {
                    return 'Empty values not allowed.';
                }
            },
            params: function(params) {
                // add additional params from data-attributes of trigger element
                params.ap_role_id = $(this).editable().data('role_id');
                params.type = 'date';
                params.resource = $(this).editable().data('sc');
                params.project_id = $(this).editable().data('dep_id');
                params.user_id = $(this).editable().data('user_id');
                params.inia_project_id = $(this).editable().data('inia_project');
                return params;
            }
        })
    });

    //================================================================================



    $('.search_dept').attr('disabled', 'true')
  $('.inia_projects').css('max-height',$(window).height()-185).css('overflow','scroll').css('overflow-x','hidden');
//  $('.tab-content').css('max-height',$(window).height()-255).css('overflow','scroll').css('overflow-x','hidden');
    $("#report_container").css('max-height',$(window).height()-255).css('overflow','scroll').css('overflow-x','hidden');
  $('#content').css('min-height', $(window).height()-185)
  $('.user_search,.dept_search,.project_users').css('width','200px');

  $('.dept_search').on("change", function(e) {
    if ($('.dept_search').select2('val') != '') {
      $('.search_dept').removeAttr('disabled')
    }else{$('.search_dept').attr('disabled', 'true')}
  });

  $('.user_search').select2({
    placeholder: "Select a user.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  var query_params = window.location.href.split('?');
  var project = query_params[0].split('/');
  project_id = project[project.length-1]



  $('.project_users').select2({
    placeholder: "Select a user.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term,
          project_id: project_id,
          state: 'dept_user'
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  $('.dept_search').select2({
    placeholder: "Select a Dept.",
    allowClear: true,
    ajax: {
      url: '/inia_members/group_users',
      dataType: 'json',
      type: "GET",
      quietMillis: 50,
      data: function (term) {
        return {
          term: term,
          type: 'dept'
        };
      },
      results: function (data) {
        var myResults = [];
        $.each(data.result, function (index, item) {
          myResults.push({
            'id': item.id,
            'text': item.text
          });
        });
        return {
          results: myResults
        };
      }
    },
    initSelection: function (item, callback) {
      var id = item.val();
      var text = item.data('option');
      var data = { id: id, text: text };
      callback(data);
    },
    formatSelection: function (item) { return (item.text); },
    escapeMarkup: function (m) { return m; }
  });

  $('.repeat_a').click(function(){
    var nc = $(this).attr('class').split(' ')
    nc = nc[nc.length-1]
    console.log('--------')
    console.log(nc)
    var da = $(this).closest('tr').find('.'+nc).select2('data')
    var data = $(this).closest('tr').nextAll('')
    $.each( data, function( i, l ){
      $(this).find('.'+nc).select2('data',da)
      $(this).find('.config_save').removeAttr('disabled')
      $(this).find('form').append("<input type='hidden' name='a3' value="+ da['id'] +">")
    })
  });

//  $('.repeat_a4').click(function(){
//    var da1 = $(this).closest('tr').find('.name_search_a4').select2('data')
//    var data1 = $(this).closest('tr').nextAll('')
//    $.each( data1, function( i, l ){
//      $(this).find('.name_search_a4').select2('data',da1)
//
//      $(this).find('form').appendTo("<input type='hidden' name='a3' value="+ da1['id'] +">")
//    })
//  });

  $('.config_save').click(function(){
    var cur = $(this)
    var fd = $(this).closest('tr').find('form ').serialize();
    var users = $(this).closest('tr').find('.repeat_a').closest('td').find(".select2-container.user_search")
    var project = $(this).closest('tr').find('td').eq(0).text()
    var st = 1;
    console.log($(this).closest('tr').find('td'));
    $.each( users, function( ) {
      if ($(this).select2('val') == ''){
        st =0
        $('.notification-msg').show();
        $('.notification-msg').html("<li >Approval level was missing in '"+ project.toUpperCase() +"' project please add and continue.</li>")
        return false;
      }
    });
    if (st == 1) {
      $.ajax({
        url: '/inia_members',
        data: fd,
        type: 'POST',
        dataType: "json",
        success: function (data) {
          cur.attr('disabled', 'disabled')
          console.log(data);
        }
      });
    }
  });

  $('.select2-search-choice-close').filter(':visible').change(function(){

  });

  $('.save_all_approver').click(function(){
    var forms = $('.report_tble tr form')
    $.each(forms, function( ) {
      console.log($(this).serialize())
      array_form = $(this).serialize();
      var users = $(this).closest('tr').find('.repeat_a').closest('td').find(".select2-container.user_search")
      var project = $(this).closest('tr').find('td').eq(0).text()
      var st = 1;
      console.log($(this).closest('tr').find('td'));
      $.each( users, function( ) {
        if ($(this).select2('val') == ''){
          st =0
          $('.notification-msg').show();
          $('.notification-msg').html("<li >Approval level was missing in '"+ project.toUpperCase() +"' project please add and continue.</li>")
          return false;
        }
      });

      if (st == 1) {
        $.ajax({
          url: '/inia_members',
          data: array_form,
          type: 'POST',
          async: true,
          dataType: "json",
          success: function (data) {
            console.log(data);
          }
        });
      }else{ return false;}
    });

  });

  $('.user_search, .project_users').on("change", function(e) {
    $(this).closest('tr').find('.config_save').removeAttr('disabled')
    $('.save_all_approver').removeAttr('disabled')
  });
  if ($('.report_tble').is(":visible")){
    $('.save_all_approver').show()
  }
  $('.restricted').select2('disable');
  $('.project_users').click(function(){
    $('#errorExplanation').hide();
  });
  $('.restricted').click(function(){
    $('.flash').hide();
    $('#errorExplanation').show().html("<ul><li>This Role restricted by Nanba Admin</li></ul> ");
    return false;
  });

  $('input[type=button].save_all_approver').click(function(){
    var data = $('#member_role_form').serializeArray();
    $.post("/inia_members/0", data);
  });

});