class CreateDelegationAudits < ActiveRecord::Migration
  def change
    create_table "delegation_audits", :force => true do |t|
      t.integer :inia_project_id
      t.integer :project_id
      t.integer :approval_role_id
      t.integer :primary_user_id
      t.integer :secondary_user_id
      t.integer :delegated_by
      t.date :from_date
      t.date :to_date
      t.boolean :status
      t.timestamps
    end
  end

end
