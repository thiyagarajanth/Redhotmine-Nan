class AddColumnToDelegationAudits < ActiveRecord::Migration
  def change
    add_column :delegation_audits, :is_auto_delegation, :boolean
    add_column :delegation_audits, :approval_role_user_id, :integer
  end
end
