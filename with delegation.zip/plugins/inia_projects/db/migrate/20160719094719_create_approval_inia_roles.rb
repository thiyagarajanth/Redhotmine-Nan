class CreateApprovalIniaRoles < ActiveRecord::Migration
  def change
    create_table :approval_inia_roles do |t|
      t.integer  :approval_role_id
      t.text  :inia_role_id
      t.text  :nanba_approval_role_ids
      t.timestamps
    end
  end
end
